<html>
<head>
	<title>Nombre Secret</title>
</head>
<body>

	<?php
		
		/* recuperer les valeurs passer par la m�thode POST */
		
	?>
	
		<?PHP
		  if($NbreAlea == $NbreSaisi){
				/* A compl�ter */
			
		  }
		  if($NbreAlea < $NbreSaisi){
		    echo "Votre nombre est trop grand !!";
				/* A compl�ter */
		  }
		  if($NbreAlea > $NbreSaisi){
			echo "Votre nombre est trop petit !!";
				/* A compl�ter */
		  }
		?>
	

</body>
</html>
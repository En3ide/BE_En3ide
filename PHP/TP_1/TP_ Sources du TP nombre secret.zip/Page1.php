<html>
<head>
	<title>Le nombre Secret</title>
</head>
<body>
	
	<center>
	<H1>Le nombre secret</H1>
	<P>
	Devinez le nombre genere aleatoirement avec le minimum d'essai possible.
	</P>

	<FORM Action="Page2.php" Method="POST">
		<?php
			
			$NbreAlea = rand(0,100);
			/*..........................*/
			
		?>
		
		<INPUT Type="Submit" Value="Jouer !">
	</FORM>
	</center>


</body>
</html>
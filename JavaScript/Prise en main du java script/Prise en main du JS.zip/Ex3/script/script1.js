onLoad=alert("Bienvenue sur ma page !")
function exemple() {
    el = document.getElementById("example");
    el.style.visibility = (el.style.visibility == "visible") ? "hidden" : "visible";
    }
/*type="text/javascript">
            document.write("<p>Du texte écrit en java script.</p>");
            alert("Hello world ! en java script");*/
function exemple() {
    el = document.getElementById("example");
    el.style.visibility = (el.style.visibility == "visible") ? "hidden" : "visible";
    }
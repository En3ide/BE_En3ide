onLoad=alert("Bienvenue sur ma page !")
function PromptMessage() {
    var saisie = prompt("Saisissez une année :", "Annee")
    console.log(saisie);
    //isAnneeBissextile(saisie);
    //return saisie;
}
function isAnneeBissextile(a) {
    var f = 0;
     if (a < 2000) {
        console.log(Je sais pas.)
     }
     if (a > 2000) {
        for (i; i < 100; i+4) {
            if (a == i) {
                i=101;
                console.log("OK");
                return 0;
            }
            if 
            console.log(i);
        }
     }
}